﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Evidence_položek_v_obchodě
{
    /// <summary>
    /// Interakční logika pro Add.xaml
    /// </summary>




    public partial class Add : Window
    {
        

        internal Položky NewItem { get; set; }

        public Add()
        {
            
            NewItem = new Položky();
        }

        private void Add_Click(object sender, RoutedEventArgs e) 
        {
            try
            {
                
                NewItem.Id = int.Parse(IdTextBox.Text);
                NewItem.Name = NameTextBox.Text;
                NewItem.Quantity = int.Parse(QuantityTextBox.Text);
                NewItem.Price = decimal.Parse(PriceTextBox.Text);
                DialogResult = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}




